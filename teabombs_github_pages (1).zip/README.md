# Teabombs Webbutik

Detta projekt innehåller två sidor:

- **Admin** (du): `/admin/index.html`
- **Kundvy** (kunder): `/kund/index.html`

## 🪄 Publicera via GitHub Pages

1. Gå till [https://github.com/new](https://github.com/new) och skapa ett nytt repo med namnet **teabombs**.
2. Ladda upp hela mappen (inklusive `admin/` och `kund/`).
3. Gå till `Settings` → `Pages` → välj `Deploy from branch` → välj `main` och `/ (root)`.
4. Tryck `Save`. Vänta 1–2 minuter.
5. Din webbplats finns nu på:  
   `https://ditt-användarnamn.github.io/teabombs/`

### Länkar
- Kundsida: `https://ditt-användarnamn.github.io/teabombs/kund/`
- Adminsida: `https://ditt-användarnamn.github.io/teabombs/admin/`

Du kan testa lokalt genom att öppna `kund/index.html` och `admin/index.html` direkt i webbläsaren.
